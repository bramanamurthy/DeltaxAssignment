package com.adjivaRegistrationPage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPage extends Base
{
	//Invoking the elements from the current driver
	public RegistrationPage(String browserName)	
	{
		PageFactory.initElements(setDriver(browserName), this); 	
	}	
	
	@FindBy(xpath="//input[starts-with(@name,'first_name')]")
	WebElement txtFirstName;
	
	@FindBy(xpath="//small[@data-bv-validator-for='first_name'][@data-bv-validator='stringLength']")
	WebElement lengthHelpMessageForFirstName;
	
	@FindBy(xpath="//small[@data-bv-validator-for='first_name'][@data-bv-validator='notEmpty']")
	WebElement nonemptyHelpMessageForFirstName;
	
	@FindBy(name="last_name")
	WebElement txtLastName;
	
	@FindBy(xpath="//small[@data-bv-validator-for='last_name'][@data-bv-validator='stringLength']")
	WebElement lengthHelpMessageForLastName;
	
	@FindBy(xpath="//small[@data-bv-validator-for='last_name'][@data-bv-validator='notEmpty']")
	WebElement nonemptyHelpMessageForLastName;	
	
	@FindBy(name="department")
	WebElement listDepartmentOffice;
	
	@FindBy(name="user_name")
	WebElement txtUserName;
	
	@FindBy(xpath="//small[@data-bv-validator-for='user_name'][@data-bv-validator='stringLength']")
	WebElement lengthHelpMessageForUserName;
	
	@FindBy(xpath="//small[@data-bv-validator-for='user_name'][@data-bv-validator='notEmpty']")
	WebElement nonemptyHelpMessageForUserName;
	
	@FindBy(name="user_password")
	WebElement txtPassword;
	
	@FindBy(xpath="//small[@data-bv-validator-for='user_password'][@data-bv-validator='stringLength']")
	WebElement lengthHelpMessageForUserPassword;
	
	@FindBy(xpath="//small[@data-bv-validator-for='user_password'][@data-bv-validator='notEmpty']")
	WebElement nonemptyHelpMessageForUserPassword;
	
	@FindBy(name="confirm_password")
	WebElement txtConfirmPasword;
	
	@FindBy(xpath="//small[@data-bv-validator-for='confirm_password'][@data-bv-validator='stringLength']")
	WebElement lengthHelpMessageForCofirmPassword;
	
	@FindBy(xpath="//small[@data-bv-validator-for='confirm_password'][@data-bv-validator='notEmpty']")
	WebElement nonemptyHelpMessageForCofirmPassword;
	
	@FindBy(name="email")
	WebElement txtEmail;
	
	@FindBy(xpath="//small[@data-bv-validator-for='email'][@data-bv-validator='stringLength']")
	WebElement lengthHelpMessageForEmail;
	
	@FindBy(xpath="//small[@data-bv-validator-for='email'][@data-bv-validator='notEmpty']")
	WebElement nonemptyHelpMessageForEmail;
	
	@FindBy(name="contact_no")
	WebElement txtContactNo;
	
	@FindBy(xpath="//small[@data-bv-validator-for='contact_no'][@data-bv-validator='stringLength']")
	WebElement lengthHelpMessageForContactNo;
	
	@FindBy(tagName="button")
	WebElement btnSubmit;	
		
	public String getTxtFirstName()	{
		return  txtFirstName.getAttribute("value");	}	
	public void setTxtFirstName(String text)	{
		txtFirstName.sendKeys(text);	}
	public String getInvalidHelpMessageForFirstName()	{
		return  lengthHelpMessageForFirstName.getText()	;}
	public String getNonEmptyHelpMessageForFirstName()	{
		return  nonemptyHelpMessageForFirstName.getText();	}
	
	public String getTxtLastName()	{
		return  txtLastName.getAttribute("value");	}	
	public void setTxtLastName(String text)	{
		txtLastName.sendKeys(text);	}
	public String getInvalidHelpMessageForLastName()	{
		return  lengthHelpMessageForLastName.getText()	;}
	public String getNonEmptyHelpMessageForLastName()	{
		return  nonemptyHelpMessageForLastName.getText();	}
	
	public void setListDepartmentOffice(String actualLocation)	{
		new Select(listDepartmentOffice).selectByVisibleText(actualLocation);}
	public String getListDepartmentOffice()	{
		String selectedOption=new Select(listDepartmentOffice).getFirstSelectedOption().getText();
		return selectedOption;	}
		
	public String getTxtUserName()	{
		return  txtUserName.getAttribute("value");	}		
	public void setTxtUserName(String text)	{
		txtUserName.sendKeys(text);	}
	public String getInvalidHelpMessageForUserName()	{
		return  lengthHelpMessageForUserName.getText()	;}
	public String getNonEmptyHelpMessageForUserName()	{
		return  nonemptyHelpMessageForUserName.getText();	}
	
	
	public String getTxtPassword()	{
		return  txtPassword.getAttribute("value");	}		
	public void setTxtPassword(String text)	{
		txtPassword.sendKeys(text);	}
	public String getInvalidHelpMessageForPassword()	{
		return  lengthHelpMessageForUserPassword.getText()	;}
	public String getNonEmptyHelpMessageForPassword()	{
		return  nonemptyHelpMessageForUserPassword.getText();	}
	
	public String getConfirmPasword()	{
		return  txtConfirmPasword.getAttribute("value");	}		
	public void setConfirmPasword(String text)	{
		txtConfirmPasword.sendKeys(text);	}
	public String getInvalidHelpMessageForConfirmPassword()	{
		return  lengthHelpMessageForCofirmPassword.getText()	;}
	public String getNonEmptyHelpMessageConfirmPassword()	{
		return  nonemptyHelpMessageForCofirmPassword.getText();	}
	
	public String getTxtEmail()	{
		return  txtEmail.getAttribute("value");	}		
	public void setTxtEmail(String text)	{
		txtEmail.sendKeys(text);	}
	public String getInvalidHelpMessageForEmail()	{
		return  lengthHelpMessageForEmail.getText()	;}
	public String getNonEmptyHelpMessageEmail(){
		return  nonemptyHelpMessageForEmail.getText();	}
	
	
	public String getContactNo()	{
		return  txtContactNo.getAttribute("value");	}
	public String getInvalidHelpMessageForContactNo()	{
		return  lengthHelpMessageForContactNo.getText()	;}
	
	public void setContactNo(String text)	{
		txtContactNo.sendKeys(text);	}	
	
	//method to click on the Submit Button
	public void clkBtnSubmit()
	{
		btnSubmit.click();
	}
}
