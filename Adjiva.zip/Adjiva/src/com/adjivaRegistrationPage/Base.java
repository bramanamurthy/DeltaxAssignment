package com.adjivaRegistrationPage;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.chrome.ChromeDriver; 
import org.openqa.selenium.firefox.FirefoxDriver;
public class Base 
{
	static private WebDriver driver;
	WebDriver setDriver(String driverName)
	{
		if((driverName.toUpperCase()).equalsIgnoreCase("CHROME"))
		{
			System.setProperty("webdriver.chrome.driver","D:/RAMANA/STUDY/SELENIUM/Downloads/chromedriver.exe");			
			driver=new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.manage().window().maximize();
		}
		else if((driverName.toUpperCase()).equalsIgnoreCase("FIREFOX"))
		{		
			System.setProperty("webdriver.gecko.driver","D:/RAMANA/STUDY/SELENIUM/Downloads/geckodriver.exe");
			driver=new FirefoxDriver();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);			
		}
		else if((driverName.toUpperCase()).equalsIgnoreCase("IE")||(driverName.toUpperCase()).equalsIgnoreCase("INTERNET EXPLORER")||(driverName.toUpperCase()).equalsIgnoreCase("INTERNETEXPLORER"))
		{			
			System.setProperty("webdriver.ie.driver","D:/RAMANA/STUDY/SELENIUM/Downloads/IEDriverServer.exe");
			DesiredCapabilities cap=DesiredCapabilities.internetExplorer();
			cap.setVersion("11");
			
			driver=new InternetExplorerDriver();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}		
		else
		{			
			System.out.println("Plese specify valid browser name");
		}
		return driver;		
	}	
	//This method is to launch the respective URL
	public void goToUrl(String url)
	{
		driver.get(url);
	}
	public void waitForField(int strtime) throws InterruptedException
	{
		Thread.sleep(strtime);
	}
	
	public void quitBrowser()
	{
		if(driver!=null)
		{
			driver.quit();
		}
	}
}
