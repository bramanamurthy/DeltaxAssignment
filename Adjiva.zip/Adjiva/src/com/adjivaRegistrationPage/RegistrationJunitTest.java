package com.adjivaRegistrationPage;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.Keys;

public class RegistrationJunitTest {
	static RegistrationPage registrationpage;
	
	//TC_01:To launch the URL << http://adjiva.com/qa-test/ >>
	@BeforeClass
	public static void launch_AdjivaURL() throws InterruptedException
	{
		registrationpage=new RegistrationPage("chrome");
		System.out.println("**********************************************************************************************");
		System.out.println("TC01: - Launching the Adjiva registration URL <http://adjiva.com/qa-test/>");
		registrationpage.goToUrl("http://adjiva.com/qa-test/");
		registrationpage.waitForField(3000);
		System.out.println("**********************************************************************************************");
	}	
	
	@Test
	public void adjiva_Registration() throws InterruptedException
	{
		//TC_02:To validate the field << First Name >>
		System.out.println("TC02: - Verifying the field < First Name >");
		registrationpage.waitForField(200);
		registrationpage.setTxtFirstName("R");
		System.out.println("Field < First Name > : Single character entered");
		registrationpage.waitForField(200);
		Assert.assertEquals("This value is not valid", registrationpage.getInvalidHelpMessageForFirstName());
		System.out.println("Field < First Name > : Help message 'This value is not valid' is displayed");
		registrationpage.txtFirstName.sendKeys(Keys.BACK_SPACE);
		registrationpage.waitForField(200);
		Assert.assertEquals("Please enter your First Name", registrationpage.getNonEmptyHelpMessageForFirstName());
		System.out.println("Field < First Name > : Help message 'Please enter your First Name' is displayed");
		registrationpage.setTxtFirstName("RAMANA MURTHY");
		Assert.assertEquals("RAMANA MURTHY", registrationpage.getTxtFirstName());
		registrationpage.waitForField(200);
		System.out.println("Field < First Name > is successfully verified");
		System.out.println("**********************************************************************************************");	
		//TC_03:To validate the field << Last Name >>
		System.out.println("TC03: - Verifying the field < Last Name >");
		registrationpage.setTxtLastName("B");
		System.out.println("Field < Last Name > : Single character entered");
		registrationpage.waitForField(200);Assert.assertEquals("This value is not valid", registrationpage.getInvalidHelpMessageForLastName());
		System.out.println("Field < Last Name > : Help message 'This value is not valid' is displayed");
		registrationpage.txtLastName.sendKeys(Keys.BACK_SPACE);
		System.out.println("Field < Last Name > : Clear the field");
		registrationpage.waitForField(200);
		Assert.assertEquals("Please enter your Last Name", registrationpage.getNonEmptyHelpMessageForLastName());
		System.out.println("Field < Last Name > : Help message 'Please enter your Last Name' is displayed");
		registrationpage.setTxtLastName("BURE");
		Assert.assertEquals("BURE", registrationpage.getTxtLastName());
		System.out.println("Field < Last Name > is successfully verified");
		System.out.println("**********************************************************************************************");
		//TC_04:To validate the field << DepartmentOffice >>
		System.out.println("TC04: - Verifying the field < Department / Office >");
		registrationpage.waitForField(200);
		registrationpage.setListDepartmentOffice("Engineering");
		Assert.assertEquals("Engineering", registrationpage.getListDepartmentOffice());
		System.out.println("Field < Department / Office > : Selected 'Engineering' from the list box");
		System.out.println("Field < Department / Office > is successfully verified");
		System.out.println("**********************************************************************************************");
		//TC_05:To validate the field << Username >>
		System.out.println("TC05: - Verifying the field < Username >");
		registrationpage.waitForField(200);
		registrationpage.setTxtUserName("A");
		System.out.println("Field < Username > : Single character entered");
		registrationpage.waitForField(200);
		Assert.assertEquals("This value is not valid", registrationpage.getInvalidHelpMessageForUserName());
		System.out.println("Field < Username > : Help message 'This value is not valid' is displayed");
		registrationpage.txtUserName.sendKeys(Keys.BACK_SPACE);
		System.out.println("Field < Username > : Clear the field");
		registrationpage.waitForField(200);
		Assert.assertEquals("Please enter your Username", registrationpage.getNonEmptyHelpMessageForUserName());
		System.out.println("Field < Username > : Help message 'Please enter your Username' is displayed");
		registrationpage.setTxtUserName("bureramanamurthy");
		Assert.assertEquals("bureramanamurthy", registrationpage.getTxtUserName());
		System.out.println("Field < Username > is successfully verified");
		System.out.println("**********************************************************************************************");
		//TC_06:To validate the field << Password >>
		registrationpage.waitForField(200);
		System.out.println("TC06: - Verifying the field < Password >");
		registrationpage.setTxtPassword("D");
		System.out.println("Field < Password > : Single character entered");
		registrationpage.waitForField(200);
		Assert.assertEquals("This value is not valid", registrationpage.getInvalidHelpMessageForPassword());
		System.out.println("Field < Password > : Help message 'This value is not valid' is displayed");
		registrationpage.txtPassword.sendKeys(Keys.BACK_SPACE);
		System.out.println("Field < Password > : Clear the field");
		registrationpage.waitForField(200);
		Assert.assertEquals("Please enter your Password", registrationpage.getNonEmptyHelpMessageForPassword());
		System.out.println("Field < Password > : Help message 'Please enter your Password' is displayed");
		registrationpage.setTxtPassword("password123");
		Assert.assertEquals("password123", registrationpage.getTxtPassword());
		System.out.println("Field < Password > is successfully verified");
		System.out.println("**********************************************************************************************");
		//TC_07:To validate the field << Confirm Password >>	
		registrationpage.waitForField(200);
		registrationpage.setConfirmPasword("E");
		System.out.println("Field < Confirm Password > : Single character entered");
		registrationpage.waitForField(200);Assert.assertEquals("This value is not valid", registrationpage.getInvalidHelpMessageForConfirmPassword());
		System.out.println("Field < Confirm Password > : Help message 'This value is not valid' is displayed");
		registrationpage.txtConfirmPasword.sendKeys(Keys.BACK_SPACE);
		System.out.println("Field < Confirm Password > : Clear the field");
		registrationpage.waitForField(200);
		Assert.assertEquals("Please confirm your Password", registrationpage.getNonEmptyHelpMessageConfirmPassword());
		System.out.println("Field < Confirm Password > : Help message 'Please enter your Confirm Password' is displayed");
		registrationpage.setConfirmPasword("password123");
		Assert.assertEquals("password123", registrationpage.getConfirmPasword());
		System.out.println("Field < Confirm Password > is successfully verified");
		registrationpage.waitForField(200);
		System.out.println("**********************************************************************************************");	
		//TC_08:To validate the field << Email >>
		System.out.println("TC08: - Verifying the field < Email >");
		registrationpage.setTxtEmail("E");
		System.out.println("Field < Email > : Single character entered");
		registrationpage.waitForField(200);
		Assert.assertEquals("This value is not valid", registrationpage.getInvalidHelpMessageForEmail());
		System.out.println("Field < Email > : Help message 'This value is not valid' is displayed");
		registrationpage.txtEmail.sendKeys(Keys.BACK_SPACE);
		registrationpage.waitForField(200);
		System.out.println("Field < Email > : Clear the field");
		Assert.assertEquals("Please enter your Email Address", registrationpage.getNonEmptyHelpMessageEmail());
		System.out.println("Field < Email > : Help message 'Please enter your Email' is displayed");
		registrationpage.setTxtEmail("testemail@gmail.com");
		Assert.assertEquals("testemail@gmail.com", registrationpage.getTxtEmail());
		if (registrationpage.getTxtEmail().contains("@") && registrationpage.getTxtEmail().contains(".com"))
		System.out.println("Field < Email > : Entered e-mail contains characrts '@,.'. Hence it is a vaid e-mail");
		System.out.println("Field < Email > : Invalid e-mail");
		registrationpage.waitForField(200);
		System.out.println("Field < Email > is successfully verified");
		System.out.println("**********************************************************************************************");		
		//TC_09:To validate the field << Contact No >>
		System.out.println("TC09: - Verifying the field < Contact No >");
		registrationpage.setContactNo("5");
		System.out.println("Field < Contact No > : Single character entered");
		registrationpage.waitForField(200);
		Assert.assertEquals("This value is not valid", registrationpage.getInvalidHelpMessageForContactNo());
		System.out.println("Field < Contact No > : Help message 'This value is not valid' is displayed");
		registrationpage.txtContactNo.sendKeys(Keys.BACK_SPACE);
		System.out.println("Field < Contact No > : Clear the field");
		registrationpage.setContactNo("9929292990");
		Assert.assertEquals("9929292990", registrationpage.getContactNo());
		if (registrationpage.getContactNo().length()==10)
		System.out.println("Field < Contact No > : Entered contact no is valid and has 10 digits");
		System.out.println("Field < Contact No > : Entered contact no is not valid");
		registrationpage.waitForField(200);
		System.out.println("Field < Contact No > is successfully verified");
		System.out.println("**********************************************************************************************");
		//To click on the button << Submit >>
		System.out.println("Submitting the registration details");
		registrationpage.waitForField(3000);
		registrationpage.clkBtnSubmit();
		System.out.println("Successfully submitted details and 'Thanks' message is displayed");
		System.out.println("**********************************************************************************************");
		//To close the browser
		System.out.println("Closing the browser");
		registrationpage.quitBrowser();
		System.out.println("Browser closed successfully");
		System.out.println("**********************************************************************************************");
	}
}